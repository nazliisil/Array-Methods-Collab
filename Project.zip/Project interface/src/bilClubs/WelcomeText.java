package bilClubs;
import javax.swing.JTextArea;
import java.awt.Font;

public class WelcomeText extends JTextArea {

	public WelcomeText() {
        String text="Welcome to Bil’Clubs";
        createWelcomeMessage(text);
        setLineWrap(true);
        setWrapStyleWord(true);
        setVisible(true);
        setEditable(false);
        setFocusable(false); 
	}
    public void createWelcomeMessage(String text){
        this.setText(text);
        Font setFont = new Font("Inter", Font.BOLD, 16);
        this.setFont(setFont);
    }

}
