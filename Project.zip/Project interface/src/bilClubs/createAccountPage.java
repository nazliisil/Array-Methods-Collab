package bilClubs;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JLayeredPane;
import javax.swing.JTextArea;

public class createAccountPage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					createAccountPage window = new createAccountPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public createAccountPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(createAccountPage.class.getResource("/bilClubs/loginframe4.png")));
		lblNewLabel.setBounds(0, 0, 350, 400);
		
		SettingsButton settingsButton = new SettingsButton();
		settingsButton.setBounds(1480, 20, 44, 44);
		frame.getContentPane().add(settingsButton);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(createAccountPage.class.getResource("/bilClubs/textarea.png")));
		lblNewLabel_1.setBounds(16, 61, 318, 41);
		
		JLabel lblNewLabel_2 = new JLabel("Bilkent Webmail");
		lblNewLabel_2.setBounds(18, 40, 130, 16);
        Font setFont = new Font("Inter", Font.BOLD, 16);
        lblNewLabel_2.setFont(setFont);
        
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon(createAccountPage.class.getResource("/bilClubs/textarea.png")));
		lblNewLabel_3.setBounds(16, 157, 318, 41);
		
		JLabel lblNewLabel_4 = new JLabel("Password");
		lblNewLabel_4.setBounds(18, 136, 100, 16);
        Font setFont2 = new Font("Inter", Font.BOLD, 16);
        lblNewLabel_4.setFont(setFont2);
        
		ContinueButton continueButton = new ContinueButton();
		continueButton.setBounds(16, 244, 318, 40);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(22, 70, 318, 41);
		textArea.setFont(new Font("Inter", Font.PLAIN, 16));
		textArea.setOpaque(false);
		textArea.setEditable(true);
		
		JTextArea textArea2 = new JTextArea();
		textArea2.setBounds(22, 166, 318, 41);
		textArea2.setFont(new Font("Inter", Font.PLAIN, 16));
		textArea2.setOpaque(false);
		textArea2.setEditable(true);
		
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(600, 241, 350, 400);
		layeredPane.setLayout(null);
		frame.getContentPane().add(layeredPane);

		layeredPane.add(lblNewLabel, Integer.valueOf(0));
		layeredPane.add(lblNewLabel_1, Integer.valueOf(1));
		layeredPane.add(lblNewLabel_2, Integer.valueOf(1));
		layeredPane.add(lblNewLabel_3, Integer.valueOf(1));
		layeredPane.add(lblNewLabel_4, Integer.valueOf(1));
		layeredPane.add(continueButton, Integer.valueOf(1));
		layeredPane.add(textArea, Integer.valueOf(2));
		layeredPane.add(textArea2, Integer.valueOf(2));
		
		

		
		
		
	}
}
