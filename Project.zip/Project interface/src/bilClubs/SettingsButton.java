package bilClubs;
import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class SettingsButton extends JButton {
	private ImageIcon settings;

	public SettingsButton(){
		this.setBackground(Color.WHITE);
    	addSettingsButton();
    	this.setPreferredSize(new Dimension(45, 45));
	}
	public void addSettingsButton(){
    	URL settingsURL = getClass().getResource("Settings.png");
        settings= new ImageIcon(settingsURL);
        
        this.setIcon(settings);
    	this.setBackground(Color.WHITE);
        this.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent a){
                addMouse2();
            }
        });
    }
    public void addMouse2(){
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	URL settingsClickedURL = getClass().getResource("settingsclicked.png");
                ImageIcon settingsClicked= new ImageIcon(settingsClickedURL);
                setIcon(settingsClicked);
                setBackground(Color.WHITE);
            }
            public void mouseReleased(MouseEvent e){
            	setBackground(Color.WHITE);
                setIcon(settings);
            }
        });
    }

}
