package bilClubs;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.net.URL;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JLabel;

public class Windowfolder {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Windowfolder window = new Windowfolder();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Windowfolder() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("BilClubs");
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		DesignButton designButton = new DesignButton();
		designButton.setBounds(635, 454, 318, 40);
		frame.getContentPane().add(designButton);
		
		DesignButton2 designButton2 = new DesignButton2();
		designButton2.setBounds(635, 375, 318, 40);
		frame.getContentPane().add(designButton2);
		
		WelcomeText welcomeText = new WelcomeText();
		welcomeText.setBounds(710, 318, 277, 27);
		frame.getContentPane().add(welcomeText);
		
		WelcomeText2 welcomeText2 = new WelcomeText2();
		welcomeText2.setBounds(710, 345, 179, 27);
		frame.getContentPane().add(welcomeText2);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Windowfolder.class.getResource("/bilClubs/bilclubs logo 1.png")));
		lblNewLabel.setBounds(739, 210, 100, 100);
		frame.getContentPane().add(lblNewLabel);
		
		SettingsButton settingsButton = new SettingsButton();
		settingsButton.setBounds(1480, 20, 44, 44);
		frame.getContentPane().add(settingsButton);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(Windowfolder.class.getResource("/bilClubs/divider7.png")));
		lblNewLabel_1.setBounds(666, 427, 250, 12);
		frame.getContentPane().add(lblNewLabel_1);
		
	}
}
