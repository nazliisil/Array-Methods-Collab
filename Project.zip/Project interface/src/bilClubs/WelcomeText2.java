package bilClubs;
import javax.swing.JTextArea;
import java.awt.Font;

public class WelcomeText2 extends JTextArea{

	public WelcomeText2() {
        String text="Enter your WebMail to continue";
        createWelcomeMessage2(text);
        setLineWrap(true);
        setWrapStyleWord(true);
        setVisible(true);
        setEditable(false);
        setFocusable(false);
	}
    public void createWelcomeMessage2(String text){
        this.setText(text);
        Font setFont = new Font("Inter", Font.PLAIN, 12);
        this.setFont(setFont);
    }
}
