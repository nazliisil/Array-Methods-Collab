package bilClubs;
import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class DesignButton extends JButton {
	private ImageIcon logIn;

	public DesignButton() {
    	addLogInButton();
    	this.setPreferredSize(new Dimension(318, 40));
	}
	public void addLogInButton(){
    	URL loginURL = getClass().getResource("login2.png");
        logIn= new ImageIcon(loginURL);


        this.setIcon(logIn);
        this.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent a){
                addMouse();
            }
        });
    }
    public void addMouse(){
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	URL loginClickedURL = getClass().getResource("loginclicked2.png");
                ImageIcon logInClicked= new ImageIcon(loginClickedURL); 

                setIcon(logInClicked);
            }
            public void mouseReleased(MouseEvent e){
                setIcon(logIn);
            }
        });
    }

}
