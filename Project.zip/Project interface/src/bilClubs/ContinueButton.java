package bilClubs;
import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class ContinueButton extends JButton {
	private ImageIcon continueButton;

	public ContinueButton(){
    	addContinueButton();
    	this.setPreferredSize(new Dimension(318, 40));
	}
	public void addContinueButton(){
    	URL continueURL = getClass().getResource("createaccount.png");
        continueButton= new ImageIcon(continueURL);
        
        this.setIcon(continueButton);
        this.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent a){
                addMouse2();
            }
        });
    }
    public void addMouse2(){
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	URL continueClickedURL = getClass().getResource("createaccountclicked.png");
                ImageIcon continueClicked= new ImageIcon(continueClickedURL); 
                setIcon(continueClicked);
            }
            public void mouseReleased(MouseEvent e){
                setIcon(continueButton);
            }
        });
    }

}
