package bilClubs;
import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class DesignButton2 extends JButton {
	private ImageIcon signUp;

	public DesignButton2(){
    	addLogInButton2();
    	this.setPreferredSize(new Dimension(270, 40));
	}
	public void addLogInButton2(){
    	URL signUpURL = getClass().getResource("signup2.png");
        signUp= new ImageIcon(signUpURL);
        
        this.setIcon(signUp);
        this.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent a){
                addMouse2();
            }
        });
    }
    public void addMouse2(){
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	URL signupClickedURL = getClass().getResource("signupclicked2.png");
                ImageIcon signupClicked= new ImageIcon(signupClickedURL); 
                setIcon(signupClicked);
            }
            public void mouseReleased(MouseEvent e){
                setIcon(signUp);
            }
        });
    }

}
