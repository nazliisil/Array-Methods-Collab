import java.io.IOException;
import java.rmi.server.ExportException;

import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.*;

public class App extends Application{

    public void start(Stage stage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("/fxml/welcomescenebuilder.fxml"));
        Scene scene = new Scene(root); 
        stage.setScene(scene); 
        stage.show(); 

    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
