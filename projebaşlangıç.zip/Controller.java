import java.io.IOException;
import java.lang.reflect.Field;

import javax.print.attribute.standard.Fidelity;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.*;

public class Controller {
    //instances
    private Stage stage;
    @FXML
    private TextField webmailLoginField;
    @FXML
    private PasswordField webmailPasswordField;
    @FXML 
    private Label wrongInfoLabel;
    
    public void switchToLogin(ActionEvent e) throws IOException{
        Parent loginRoot = FXMLLoader.load(getClass().getResource("/fxml/loginscenebuilder.fxml"));

        //stage i getiriyoruz
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        Scene loginScene = new Scene(loginRoot);
        stage.setScene(loginScene);
        stage.show();
    }
        public void switchToNamePage(ActionEvent e) throws IOException{
        Parent nameRoot = FXMLLoader.load(getClass().getResource("/fxml/namePage.fxml"));

        //stage i getiriyoruz
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        Scene singUpScene = new Scene(nameRoot);
        stage.setScene(singUpScene);
        stage.show();
    }

    public void switchToSignUp(ActionEvent e) throws IOException{
        Parent signUpRoot = FXMLLoader.load(getClass().getResource("/fxml/signupscenebuilder.fxml"));

        //stage i getiriyoruz
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        Scene singUpScene = new Scene(signUpRoot);
        stage.setScene(singUpScene);
        stage.show();
    }
    public void switchToInterest(ActionEvent e) throws IOException{
        Parent interestRoot = FXMLLoader.load(getClass().getResource("/fxml/interestpage2.fxml"));

        //stage i getiriyoruz
        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        Scene singUpScene = new Scene(interestRoot);
        stage.setScene(singUpScene);
        stage.show();
    }

    public void getMailText(ActionEvent e) throws IOException{
        String mail = webmailLoginField.getText();
        String password = webmailPasswordField.getText();
        
        boolean accurate = LoginVerifier.verify(mail, password);

        if(accurate){

            Parent mainPage = FXMLLoader.load(getClass().getResource("/fxml/defaultpage.fxml"));
            Scene mainScene = new Scene(mainPage);
            stage = (Stage)((Node)e.getSource()).getScene().getWindow();
            stage.setScene(mainScene);

        }

        else{
            wrongInfoLabel.setVisible(true);
        }
    }

}
