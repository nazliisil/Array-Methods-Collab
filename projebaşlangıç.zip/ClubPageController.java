import java.io.IOException;
import java.lang.reflect.Field;

import javax.print.attribute.standard.Fidelity;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.scene.*;
import javafx.scene.image.*;

public class ClubPageController {
    private Stage stage;
    private ImageView clubPhoto;
    private Label clubName;
    private Label descriptionLabel;
    private Club club;

    public void switchToClub(ActionEvent e) throws IOException{
        Parent clubRoot = FXMLLoader.load(getClass().getResource("/fxml/defaultpage.fxml"));
        clubPhoto.setImage(club.getPhoto());
        descriptionLabel.setText(club.getDescription());
        clubName.setText(club.getName());

        stage = (Stage)((Node)e.getSource()).getScene().getWindow();

        Scene loginScene = new Scene(clubRoot);
        stage.setScene(loginScene);
        stage.show();
    }
}
