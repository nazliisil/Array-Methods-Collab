package bilClubs;
import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class DesignButton extends JButton {
    private ImageIcon logIn;
    
    public DesignButton() {
    	addLogInButton();
 
    }
    public void addLogInButton(){
    	URL loginURL = getClass().getResource("/login.jpg");
        logIn= new ImageIcon(loginURL);
        
        this.setIcon(logIn);
        this.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent a){
                addMouse();
            }
        });
    }
    public void addMouse(){
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	URL loginClickedURL = getClass().getResource("/loginclicked.jpg");
                ImageIcon logInClicked= new ImageIcon(loginClickedURL); 
                setIcon(logInClicked);
            }
            public void mouseReleased(MouseEvent e){
                setIcon(logIn);
            }
        });
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JButton myButton = new DesignButton();
	}

}
