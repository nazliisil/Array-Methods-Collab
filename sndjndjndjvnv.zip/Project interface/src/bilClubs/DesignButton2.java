package bilClubs;
import javax.swing.*; 
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class DesignButton2 extends JButton {
    private ImageIcon logIn2;
    
    public DesignButton2() {
    	addLogInButton2();
 
    }
    public void addLogInButton2(){
    	URL loginURL2 = getClass().getResource("/signup.jpg");
        logIn2= new ImageIcon(loginURL2);
        
        this.setIcon(logIn2);
        this.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent a){
                addMouse2();
            }
        });
    }
    public void addMouse2(){
        this.addMouseListener(new MouseAdapter(){
            public void mousePressed(MouseEvent e){
            	URL loginClickedURL2 = getClass().getResource("/signupclicked.jpg");
                ImageIcon logInClicked2= new ImageIcon(loginClickedURL2); 
                setIcon(logInClicked2);
            }
            public void mouseReleased(MouseEvent e){
                setIcon(logIn2);
            }
        });
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JButton myButton = new DesignButton2();
	}

}
