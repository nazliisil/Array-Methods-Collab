package bilClubs;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JTextArea;

public class Windowfolder {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Windowfolder window = new Windowfolder();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Windowfolder() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("BilClubs");
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		DesignButton designButton = new DesignButton();
		designButton.setBounds(683, 434, 249, 40);
		frame.getContentPane().add(designButton);
		
		DesignButton2 designButton2 = new DesignButton2();
		designButton2.setBounds(683, 384, 249, 40);
		frame.getContentPane().add(designButton2);
		
		WelcomeText welcomeText = new WelcomeText();
		welcomeText.setBounds(725, 328, 277, 27);
		frame.getContentPane().add(welcomeText);
		
		WelcomeText2 welcomeText2 = new WelcomeText2();
		welcomeText2.setBounds(725, 355, 179, 27);
		frame.getContentPane().add(welcomeText2);
	}
}
